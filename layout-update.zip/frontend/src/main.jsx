/**
 * main.jsx - React entry point. Mounts the App component into the DOM.
 */

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./svg/App.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
